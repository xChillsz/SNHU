from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, db):
        
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:47534' % (username, password))
        self.database = self.client[db]

    
# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary           
            return True
        else: 
            return False

# Create method to implement the R in CRUD.
    def read(self,search):
        #If null returns exception
        if search is not None:
            if search:
                searchResult = self.database.animals.find_one(search,{"_id":False})
                return searchResult
            else:
                exception = self.database.animals.getLastError()
                return exception
            
    def returnAll(self,search,limit):
        if limit is None:
            searchResult = list(self.database.animals.find(search,{"_id":False}))
        else:
            searchResult = list(self.database.animals.find(search,{"_id":False}).limit(limit))
        return searchResult

# Create method to implement the U in CRUD
    def update(self, searchInfo, updateInfo):
        if searchInfo is not None:
            updates = self.database.animals.update_many(searchInfo,{"$set":updateInfo})
            result = updates.raw_result
            return result
        else:
            exception = self.database.animals.getLastError()
            return exception
        

# Create method to implement the D in CRUD

    def delete(self, deleteObj):
        if deleteObj is not None:
            delete = self.database.animals.delete_many(deleteObj)
            result = delete.raw_result
            return result
        else:
            exception = self.database.animals.getLastError()
            return exception