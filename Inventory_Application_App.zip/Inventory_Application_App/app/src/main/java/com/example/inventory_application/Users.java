package com.example.inventory_application;

public class Users {
        private String userName;
        private String password;
        private boolean notificationTF;
        private int id;

        // creating getter and setter methods
        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getPassword() {
            return password;
        }


        public void setPassword(String password) {
            this.password = password;
        }
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }
        public void setNotificationTF(boolean notificationTF) {
        this.notificationTF = notificationTF;
        }
        public boolean getNotificationTF() {
        return notificationTF;
    }
        // constructor
        public Users(Integer id, String userName, String password, Boolean notificationTF) {
            this.id = id;
            this.userName = userName;
            this.password = password;
            this.notificationTF = notificationTF;
        }
}
