package com.example.inventory_application;

public class Items {
    private String info;
    private int stock;
    private double price;
    private int id;

    // creating getter and setter methods
    public String getInfo() {
        return info;
    }
    public int getStock() {
        return stock;
    }
    public double getPrice() {
        return price;
    }
    public int getId() {
        return id;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setId(int id) {
        this.id = id;
    }

    // constructor
    public Items(int id,String info, int stock, double price) {
        this.id = id;
        this.info = info;
        this.stock = stock;
        this.price = price;
    }
}