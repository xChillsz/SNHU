package com.example.inventory_application;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "user.db";
    private static final int VERSION = 19;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_NOTIFICATION_TF = "notificationTF";

    private static final String COL_INFO = "info";

    private static final String COL_STOCK ="stock";

    private static final String COL_PRICE ="price";

    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_USERS + " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_USERNAME + " TEXT,"+ COL_PASSWORD + " TEXT,"+ COL_NOTIFICATION_TF + " BOOLEAN)";
        String query2 = "CREATE TABLE " + TABLE_ITEMS + " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "+ COL_INFO + " TEXT,"+ COL_STOCK + " INTEGER,"+ COL_PRICE + " DOUBLE)";

        db.execSQL(query);
        db.execSQL(query2);
    }

    public void addNewUser(String userName, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, userName);
        values.put(COL_PASSWORD,password);

        db.insert(TABLE_USERS, null, values);

        db.close();
    }
    public void updateUser(Integer id, String username, String password, Boolean notificationTF){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        String tempVal = id.toString();
        int notifyTF = notificationTF ? 1:0;

        db.execSQL("UPDATE " + TABLE_USERS + " SET " + COL_USERNAME + " = '" + username +"', " + COL_PASSWORD + " = '" + password +"', " + COL_NOTIFICATION_TF + " = '" + notifyTF +"'" +" WHERE " + COL_ID + " = " + tempVal + "");
        db.close();
    }
    public void addItems(String info, Integer stock, Double price){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_INFO, info);
        values.put(COL_STOCK, stock);
        values.put(COL_PRICE, price);

        db.insert(TABLE_ITEMS, null, values);
        db.close();
    }

    public void updateItem(Integer id, String info, Integer stock, Double price){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        String tempVal = id.toString();

        db.execSQL("UPDATE " + TABLE_ITEMS + " SET " + COL_INFO + " = '" + info +"', " + COL_STOCK + " = '" + stock +"', " + COL_PRICE + " = '" + price +"'" +" WHERE " + COL_ID + " = " + tempVal + "");
        db.close();
    }
    public void removeItem(Integer id){
        SQLiteDatabase db = this.getWritableDatabase();
        String tempVal = id.toString();
        db.execSQL("DELETE FROM " + TABLE_ITEMS +" WHERE " + COL_ID + " = " + tempVal + "");
        db.close();
    }


    public ArrayList<Users> readUsers(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorUsers = db.rawQuery("SELECT * FROM " + TABLE_USERS,null);

        ArrayList<Users> userArrayList = new ArrayList<>();

        if(cursorUsers.moveToFirst()){
            do{
                boolean value = cursorUsers.getInt(3)>0;
                userArrayList.add(new Users(
                        cursorUsers.getInt(0),
                        cursorUsers.getString(1),
                        cursorUsers.getString(2),
                        value));
            } while (cursorUsers.moveToNext());
        }

        cursorUsers.close();
        return userArrayList;
    }

    public ArrayList<Items> readItems(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorItems = db.rawQuery("SELECT * FROM " + TABLE_ITEMS,null);

        ArrayList<Items> itemsArrayList = new ArrayList<>();

        if(cursorItems.moveToFirst()){
            do{
                itemsArrayList.add(new Items(
                        cursorItems.getInt(0),
                        cursorItems.getString(1),
                        cursorItems.getInt(2),
                        cursorItems.getDouble(3)
                        ));
            } while (cursorItems.moveToNext());
        }

        cursorItems.close();
        return itemsArrayList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }
}
