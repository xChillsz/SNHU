package com.example.inventory_application;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.view.Gravity;
import android.widget.Toast;
import java.util.ArrayList;
import android.util.Log;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    //Private Vars
    private DBHandler userdb;

    //String Values
    String[] navButtonLabels = {"Home", "Items", "Profile"};
    String[] sectionHeaders = {"Welcome! Please Sign in to Continue.", "All Items", "Details"};
    String[] tableColumnHeaders = {"Info", "Price", "Stock", "", "", ""};

    public static ArrayList<Users> userList = null;
    public static ArrayList<Items> itemList = null;
    public static Users loggedInUser;
    public static Items currentItem;
    public static boolean passwordCheck;
    public static boolean addItemCheck = false;
    public static boolean mainTableCheck = false;
    public static boolean infoCheck = false;
    public static boolean stockCheck = false;
    public static boolean priceCheck = false;

    public static boolean notificationCheck;
    String activeHeader = navButtonLabels[0];
    String activeSectionHeader = sectionHeaders[0];
    String selectedButtonColor = "#66c2a3";
    String defaultButtonColor = "#019A66";
    String white = "#FFFFFF";

    //int

    //Text Views
    TextView titleHeader;
    TextView mainTableHeader;
    TextView loginScreenMessage;

    //Edit Text
    EditText inputUserName;
    EditText inputPassword;
    EditText inputInfo;
    EditText inputStock;
    EditText inputPrice;


    //Buttons
    Button buttonHome;
    Button buttonItems;
    Button buttonProfile;
    Button buttonNewUser;
    Button buttonLogin;
    Button buttonAddItem;
    Button buttonCancelItem;
    Button buttonSaveItem;
    Button buttonYes;
    Button buttonNo;
    ToggleButton buttonToggleNotifications;

    //Layouts
    //Relative
    RelativeLayout loginScreen;
    RelativeLayout layoutAddItem;
    RelativeLayout layoutPopupNotification;
    RelativeLayout layoutProfile;
    //Table
    TableLayout mainTable;
    //Nested Scroll
    ScrollView scrollArea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize TextViews
        titleHeader = findViewById(R.id.titleHeader);
        mainTableHeader = findViewById(R.id.mainTableHeader);
        loginScreenMessage = findViewById(R.id.loginScreenMessage);

        //EditText
        inputUserName = findViewById(R.id.inputUserName);
        inputPassword = findViewById(R.id.inputPassword);
        inputInfo = findViewById(R.id.inputInfo);
        inputStock = findViewById(R.id.inputStock);
        inputPrice = findViewById(R.id.inputPrice);

        //Set Text
        setTextViewText(titleHeader, activeHeader);

        //Initialize Scroll View
        scrollArea = findViewById(R.id.scrollArea);
        //Layouts
        loginScreen = findViewById(R.id.loginScreen);
        layoutAddItem = findViewById(R.id.layoutAddItem);
        layoutPopupNotification = findViewById(R.id.layoutPopupNotification);
        layoutProfile = findViewById(R.id.layoutProfile);

        //Initialize Buttons
        buttonHome = findViewById(R.id.buttonHome);
        buttonItems = findViewById(R.id.buttonItems);
        buttonProfile = findViewById(R.id.buttonProfile);
        buttonNewUser = findViewById(R.id.buttonNewUser);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonCancelItem = findViewById(R.id.buttonCancelItem);
        buttonSaveItem = findViewById(R.id.buttonSaveItem);
        buttonYes = findViewById(R.id.buttonYes);
        buttonNo = findViewById(R.id.buttonNo);
        buttonToggleNotifications = findViewById(R.id.toggleNotification);


        userdb = new DBHandler(MainActivity.this);
        itemList = userdb.readItems();
        if(itemList.isEmpty()) {
            //Weapons
            userdb.addItems("Sword", 5, 10.00);
            userdb.addItems("Shield", 5, 20.00);
            userdb.addItems("Dagger", 5, 10.00);
            userdb.addItems("Pistol", 5, 20.00);
            userdb.addItems("Bow", 5, 10.00);

            //Armor
            userdb.addItems("Chest Armor", 5, 25.00);
            userdb.addItems("Leg Armor", 5, 25.00);
            userdb.addItems("Wrist Armor", 5, 25.00);
            userdb.addItems("Shoulder Armor", 5, 25.00);
            userdb.addItems("Helmet", 5, 25.00);

            //Potions
            userdb.addItems("Health Potion", 5, 15.00);
            userdb.addItems("Mana Potion", 5, 25.00);
            userdb.addItems("Speed Potion", 5, 25.00);
            userdb.addItems("Attack Potion", 5, 25.00);
            userdb.addItems("Defense Potion", 5, 25.00);

            //Misc
            userdb.addItems("Water", 5, 15.00);
            userdb.addItems("Food", 5, 10.00);
            userdb.addItems("Arrows", 5, 10.00);
            userdb.addItems("Bullets", 5, 10.00);
            userdb.addItems("Rope", 5, 10.00);
        }

        scrollArea.setNestedScrollingEnabled(true);
        scrollArea.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View view, int i, int i1, int i2, int i3) {
                Log.d("scrollX", String.valueOf(i));
                Log.d("scrollY", String.valueOf(i1));
                Log.d("oldScrollX", String.valueOf(i2));
                Log.d("oldScrollY", String.valueOf(i3));
            }
        });
        //Button Nav Listeners
        //HOME BUTTON LISTENERS
        buttonHome.setOnClickListener(V -> {
            buttonChangeColor(buttonHome, selectedButtonColor);
            buttonChangeColor(buttonItems, defaultButtonColor);
            buttonChangeColor(buttonProfile, defaultButtonColor);
            activeHeader = navButtonLabels[0];
            setTextViewText(titleHeader, activeHeader);
            if (!passwordCheck) {
                loginScreen.setVisibility(View.VISIBLE);
                activeSectionHeader = sectionHeaders[0];
                setTextViewText(mainTableHeader, activeSectionHeader);
            } else {
                String tempVal = "Welcome back, " + loggedInUser.getUserName() + "! " + "\nYou can now access Items and Profile!";
                setTextViewText(mainTableHeader, tempVal);
            }
            buttonAddItem.setVisibility(View.GONE);
            if (mainTableCheck) {
                setViewVisibility(mainTable, View.GONE);
                mainTable.removeAllViewsInLayout();
            }
            if (addItemCheck) {
                layoutAddItem.setVisibility(View.GONE);
            }
            buttonItems.setClickable(true);
            buttonHome.setClickable(false);
            buttonProfile.setClickable(true);
            layoutProfile.setVisibility(View.GONE);
        });

        //NEW USER LISTENER
        buttonNewUser.setOnClickListener(V -> {
            String userName = inputUserName.getText().toString();
            String password = inputPassword.getText().toString();
            userdb.addNewUser(userName, password);
            Toast.makeText(MainActivity.this, "User has been added.", Toast.LENGTH_SHORT).show();
            inputUserName.setText("");
            inputPassword.setText("");
            userList = userdb.readUsers();
            loggedInUser = returnLoggedInUser(userList, userName);
            String tempVal = "Login has been created. Please enter credentials to continue.";
            setTextViewText(loginScreenMessage, tempVal);
            layoutPopupNotification.setVisibility(View.VISIBLE);
        });
        buttonYes.setOnClickListener(V -> {
            notificationCheck = true;
            loggedInUser.setNotificationTF(notificationCheck);
            userdb.updateUser(loggedInUser.getId(), loggedInUser.getUserName(), loggedInUser.getPassword(), loggedInUser.getNotificationTF());
            layoutPopupNotification.setVisibility(View.GONE);
        });
        buttonNo.setOnClickListener(V -> {
            notificationCheck = false;
            loggedInUser.setNotificationTF(notificationCheck);
            userdb.updateUser(loggedInUser.getId(), loggedInUser.getUserName(), loggedInUser.getPassword(), loggedInUser.getNotificationTF());
            layoutPopupNotification.setVisibility(View.GONE);
        });
        //LOGIN LISTENER
        buttonLogin.setOnClickListener(V -> {
            String userName = inputUserName.getText().toString();
            String password = inputPassword.getText().toString();
            userList = userdb.readUsers();
            if(!userList.isEmpty())
            {
            loggedInUser = returnLoggedInUser(userList, userName);
            passwordCheck = checkUserPassword(loggedInUser, password);
            if (passwordCheck) {
                String tempVal = "Welcome back, \n" + loggedInUser.getUserName() + "! " + "\nYou can now access Items and Profile!";
                setTextViewText(mainTableHeader, tempVal);
                setViewVisibility(loginScreen, View.GONE);
                buttonItems.setEnabled(true);
                buttonProfile.setEnabled(true);
                //notificationCheck = loggedInUser.getNotificationTF();
                buttonToggleNotifications.setChecked(loggedInUser.getNotificationTF());
            } else {
                String tempVal = "Credentials are incorrect. Please try again.";
                setTextViewText(loginScreenMessage, tempVal);
            }
            } else {
                String tempVal = "No users exist. Please create a user to continue.";
                setTextViewText(loginScreenMessage, tempVal);
            }
        });
        inputUserName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (TextUtils.isEmpty(s)) {
                    buttonNewUser.setEnabled(false);
                    buttonLogin.setEnabled(false);
                } else {
                    buttonNewUser.setEnabled(true);
                    buttonLogin.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        inputPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (TextUtils.isEmpty(s)) {
                    buttonNewUser.setEnabled(false);
                    buttonLogin.setEnabled(false);
                } else {
                    buttonNewUser.setEnabled(true);
                    buttonLogin.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        //ITEMS LISTENERS
        buttonItems.setOnClickListener(V -> {
            buttonChangeColor(buttonItems, selectedButtonColor);
            buttonChangeColor(buttonHome, defaultButtonColor);
            buttonChangeColor(buttonProfile, defaultButtonColor);
            activeHeader = navButtonLabels[1];
            activeSectionHeader = sectionHeaders[1];
            setTextViewText(titleHeader, activeHeader);
            setTextViewText(mainTableHeader, activeSectionHeader);
            setViewVisibility(loginScreen, View.GONE);
            if (addItemCheck) {
                layoutAddItem.setVisibility(View.VISIBLE);
            } else {
                layoutAddItem.setVisibility(View.GONE);
                buttonAddItem.setVisibility(View.VISIBLE);
            }
            itemList = userdb.readItems();
            loadGrid();
            buttonItems.setClickable(false);
            buttonHome.setClickable(true);
            buttonProfile.setClickable(true);
            layoutProfile.setVisibility(View.GONE);
        });
        //ADD ITEM LISTENER
        buttonAddItem.setOnClickListener(V -> {
            layoutAddItem.setVisibility(View.VISIBLE);
            buttonAddItem.setVisibility(View.GONE);
            addItemCheck = true;
            inputInfo.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (TextUtils.isEmpty(s)) {
                        infoCheck = false;
                        buttonSaveItem.setEnabled(false);
                    } else {
                        infoCheck = true;
                        if (stockCheck && priceCheck) {
                            buttonSaveItem.setEnabled(true);
                        }
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
            inputStock.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (TextUtils.isEmpty(s)) {
                        stockCheck = false;
                        buttonSaveItem.setEnabled(false);
                    } else {
                        stockCheck = true;
                        if (infoCheck && priceCheck) {
                            buttonSaveItem.setEnabled(true);
                        }
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
            inputPrice.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (TextUtils.isEmpty(s)) {
                        priceCheck = false;
                        buttonSaveItem.setEnabled(false);
                    } else {
                        priceCheck = true;
                        if (infoCheck && stockCheck) {
                            buttonSaveItem.setEnabled(true);
                        }
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        });
        //CANCEL BUTTON LISTENER
        buttonCancelItem.setOnClickListener(V -> {
            inputInfo.setText("");
            inputStock.setText("");
            inputPrice.setText("");
            layoutAddItem.setVisibility(View.GONE);
            buttonAddItem.setVisibility(View.VISIBLE);
            addItemCheck = false;
        });

        //SAVE BUTTON LISTENERS
        buttonSaveItem.setOnClickListener(V -> {
            String info = inputInfo.getText().toString();
            String tempStock = inputStock.getText().toString();
            String tempPrice = inputPrice.getText().toString();
            int stock = Integer.parseInt(tempStock);
            double price = Double.parseDouble(tempPrice);
            userdb.addItems(info, stock, price);
            inputInfo.setText("");
            inputStock.setText("");
            inputPrice.setText("");
            setViewVisibility(layoutAddItem, View.GONE);
            buttonAddItem.setVisibility(View.VISIBLE);
            itemList = userdb.readItems();
            mainTable.removeAllViews();
            loadGrid();
            addItemCheck = false;
        });

        //PROFILE LISTENER
        buttonProfile.setOnClickListener(V -> {
            buttonChangeColor(buttonProfile, selectedButtonColor);
            buttonChangeColor(buttonHome, defaultButtonColor);
            buttonChangeColor(buttonItems, defaultButtonColor);
            activeHeader = navButtonLabels[2];
            activeSectionHeader = sectionHeaders[2];
            setTextViewText(titleHeader, activeHeader);
            setTextViewText(mainTableHeader, activeSectionHeader);
            setViewVisibility(loginScreen, View.GONE);
            if (mainTableCheck) {
                setViewVisibility(mainTable, View.GONE);
                mainTable.removeAllViewsInLayout();
            }
            if (addItemCheck) {
                layoutAddItem.setVisibility(View.GONE);
            }
            setViewVisibility(buttonAddItem, View.GONE);
            buttonItems.setClickable(true);
            buttonHome.setClickable(true);
            buttonProfile.setClickable(false);
            layoutProfile.setVisibility(View.VISIBLE);
            buttonToggleNotifications.setChecked(loggedInUser.getNotificationTF());
        });

        buttonToggleNotifications.setOnClickListener(V -> {
            notificationCheck = !loggedInUser.getNotificationTF();
            loggedInUser.setNotificationTF(notificationCheck);
            userdb.updateUser(loggedInUser.getId(), loggedInUser.getUserName(), loggedInUser.getPassword(), notificationCheck);
            userList = userdb.readUsers();
            loggedInUser = returnLoggedInUser(userList, loggedInUser.getUserName());
            buttonToggleNotifications.setChecked(notificationCheck);
        });
    }

    public void buttonChangeColor(Button button, String color) {
        button.setBackgroundColor(Color.parseColor(color));
    }

    public void setTextViewText(TextView view, String text) {
        view.setText(text);
    }

    public void setHeaderColumns(int numOfColumns, TableRow row, int resId) {
        for (int j = 0; j < numOfColumns; j++) {
            TextView tv0;
            tv0 = new TextView(this);
            tv0.setText(tableColumnHeaders[j]);
            tv0.setTextColor(Color.parseColor(white));
            tv0.setBackgroundResource(resId);
            tv0.setGravity(Gravity.CENTER);
            tv0.setTextSize(20);
            //tv0.setTextAlignment(2);
            row.addView(tv0);
        }
    }

    public void setRowStyleProperties(int currentIndex, int numOfColumns, TableRow row, int resId, Items value) {
        row.setId(currentIndex);
        String info = value.getInfo();
        String stock = Integer.toString(value.getStock());
        String price = Double.toString(value.getPrice());
        String[] textVals = {info, price, stock, "", ""};
        for (int j = 0; j < numOfColumns; j++) {
            if (j < 3) {
                TextView tv0;
                tv0 = new TextView(this);
                tv0.setText(textVals[j]);
                tv0.setTextColor(Color.parseColor(white));
                tv0.setBackgroundResource(resId);
                tv0.setGravity(Gravity.CENTER);
                tv0.setTextSize(20);
                row.addView(tv0);
            } else if (j == 3) {
                TextView tv0;
                tv0 = new TextView(this);
                tv0.setText("-");
                tv0.setTextColor(Color.parseColor(white));
                tv0.setBackgroundResource(R.drawable.stock_enum);
                tv0.setGravity(Gravity.CENTER);
                tv0.setTextSize(20);
                tv0.setClickable(true);
                tv0.onHoverChanged(true);
                tv0.setId(value.getId());
                tv0.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        value.setStock(value.getStock() - 1);
                        userdb.updateItem(value.getId(), value.getInfo(), value.getStock(), value.getPrice());
                        itemList = userdb.readItems();
                        mainTable.removeAllViews();
                        loadGrid();
                        if(loggedInUser.getNotificationTF() && value.getStock() <= 5) {
                            String toastMsg = value.getInfo() + " is low in stock (" + value.getStock() + ").\nPlease keep the amount above 5 to avoid operation issues.";
                            Toast notificationMsg = Toast.makeText(MainActivity.this, toastMsg, Toast.LENGTH_LONG);
                            notificationMsg.setGravity(Gravity.TOP | Gravity.END, 0, 0);
                            notificationMsg.show();
                        }
                    }
                });
                //tv0.setTextAlignment(2);
                row.addView(tv0);
            } else if (j == 4) {
                TextView tv0;
                tv0 = new TextView(this);
                tv0.setText("+");
                tv0.setTextColor(Color.parseColor(white));
                tv0.setBackgroundResource(R.drawable.stock_enum);
                tv0.setGravity(Gravity.CENTER);
                tv0.setTextSize(20);
                tv0.setClickable(true);
                tv0.onHoverChanged(true);
                tv0.setId(value.getId());
                tv0.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        value.setStock(value.getStock() + 1);
                        userdb.updateItem(value.getId(), value.getInfo(), value.getStock(), value.getPrice());
                        itemList = userdb.readItems();
                        mainTable.removeAllViews();
                        loadGrid();
                    }
                });
                //tv0.setTextAlignment(2);
                row.addView(tv0);
            } else {
                TextView tv0;
                tv0 = new TextView(this);
                tv0.setText("X");
                tv0.setTextColor(Color.parseColor(white));
                tv0.setBackgroundResource(R.drawable.remove_button);
                tv0.setGravity(Gravity.CENTER);
                tv0.setTextSize(20);
                tv0.setClickable(true);
                tv0.onHoverChanged(true);
                tv0.setId(value.getId());
                tv0.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        userdb.removeItem(value.getId());
                        itemList = userdb.readItems();
                        mainTable.removeAllViews();
                        loadGrid();
                    }
                });
                //tv0.setTextAlignment(2);
                row.addView(tv0);
            }
        }
    }

    public void loadGrid() {
        //Variables
        int numOfRows = itemList.size();
        int numOfColumns = 6;
        //Initialize Table
        mainTable = findViewById(R.id.mainTable);
        mainTableCheck = true;
        mainTable.setStretchAllColumns(true);
        mainTable.setVisibility(View.VISIBLE);
        //END VARIABLES
        for (int i = -1; i < numOfRows; i++) {
            TableRow row = new TableRow(this);
            TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
            row.setLayoutParams(lp);
            if (i == -1) {
                setHeaderColumns(numOfColumns, row, R.drawable.cell_shape_header);
            } else if (i % 2 == 0) {
                currentItem = getCurrentItem(itemList, i);
                setRowStyleProperties(i, numOfColumns, row, R.drawable.cell_shape_primary, currentItem);
            } else {
                currentItem = getCurrentItem(itemList, i);
                setRowStyleProperties(i, numOfColumns, row, R.drawable.cell_shape_secondary, currentItem);
            }
            if (i == -1) {
                mainTable.addView(row, 0);
            } else {
                mainTable.addView(row, i + 1);
            }
        }
    }

    public Users returnLoggedInUser(ArrayList<Users> allUsers, String userName) {
        int arraySize = allUsers.size();
        Users singleUser = null;
        boolean matchFound = false;
        while (!matchFound) {
            for (int i = 0; i < arraySize; i++) {
                singleUser = allUsers.get(i);
                if (singleUser.getUserName().equals(userName)) {
                    matchFound = true;
                }
            }
        }
        return singleUser;
    }

    public Items getCurrentItem(ArrayList<Items> allItems, int index) {
        currentItem = allItems.get(index);
        return currentItem;
    }

    public boolean checkUserPassword(Users user, String password) {
        return user.getPassword().equals(password);
    }

    public void setViewVisibility(View main, int v) {
        main.setVisibility(v);
    }


}